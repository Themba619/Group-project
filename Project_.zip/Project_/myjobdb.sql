-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2023 at 01:57 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myjobdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `companyprofile`
--

CREATE TABLE `companyprofile` (
  `compID` int(11) NOT NULL,
  `comp_Username` varchar(255) NOT NULL,
  `comp_Name` varchar(255) NOT NULL,
  `comp_IMG` varchar(255) NOT NULL,
  `comp_Address` varchar(255) NOT NULL,
  `comp_Email` varchar(255) NOT NULL,
  `comp_TelNum` varchar(255) NOT NULL,
  `password_` varchar(255) NOT NULL,
  `comp_Descrip` varchar(255) NOT NULL,
  `Industry` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companyprofile`
--

INSERT INTO `companyprofile` (`compID`, `comp_Username`, `comp_Name`, `comp_IMG`, `comp_Address`, `comp_Email`, `comp_TelNum`, `password_`, `comp_Descrip`, `Industry`) VALUES
(2, 'absaUserName', 'ABSA Bank', 'ABSA_Group_Limited_Logo.svg.png', '317 Whispyhound dr\r\nJohannesburg\r\n1028', 'email@email.com', '+27 617 8555', 'absa1234', 'Ahh lee lee', 'Tech Industry'),
(12, 'absaUserName__', 'ABSA Bank', '1569911880686.jpeg', '2202 Days street\r\nJohannesburg\r\n1222', 'email@email.com', '+27 617 8555', 'sss', 'Ahh lee lee', 'Health and Fitness Industry'),
(13, 'capitecBank', 'Capitec Bank', 'Capitec-logo.jpg', '22 address street', 'email@email.com', '+27 617 8555', 'capitec', 'Ahh lee lee', 'Tech Industry'),
(14, 'discovery', 'Discovery Bank', 'ABSA_Group_Limited_Logo.svg.png', 'faefeaef', 'email@email.com', '+27 617 8555', 'sony', 'Ahh lee lee', 'Health and Fitness Industry'),
(15, 'discovery__', 'Discovery Bank', 'ABSA_Group_Limited_Logo.svg.png', 'faefeaef', 'eaaamail@email.com', '+27 617 8555', 'sss', 'Ahh lee lee', 'Health and Fitness Industry');

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE `jobseeker` (
  `jobSeeker_ID` int(11) NOT NULL,
  `jobSeeker_Username` varchar(255) NOT NULL,
  `jobSeeker_Name` varchar(255) NOT NULL,
  `jobSeeker_Surname` varchar(255) NOT NULL,
  `jobSeeker_Email` varchar(255) NOT NULL,
  `password_` varchar(255) NOT NULL,
  `jobSeeker_Birthdate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `postedjobs`
--

CREATE TABLE `postedjobs` (
  `JobID` int(11) NOT NULL,
  `comp_Username` varchar(255) NOT NULL,
  `JobName` varchar(255) NOT NULL,
  `JobSector` varchar(255) NOT NULL,
  `JobLocation` varchar(255) NOT NULL,
  `ContractType` varchar(255) NOT NULL,
  `WorkingHours` int(11) NOT NULL,
  `Salary` int(11) NOT NULL,
  `S_TimePeriod` varchar(255) NOT NULL,
  `J_Description` varchar(255) NOT NULL,
  `skillsRequired` varchar(255) NOT NULL,
  `EdLevels` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `postedjobs`
--

INSERT INTO `postedjobs` (`JobID`, `comp_Username`, `JobName`, `JobSector`, `JobLocation`, `ContractType`, `WorkingHours`, `Salary`, `S_TimePeriod`, `J_Description`, `skillsRequired`, `EdLevels`) VALUES
(29, 'absaUserName', 'Business Analyst', 'Tech Industry', 'Gauteng, Johannesburg', 'Permanent', 8, 20000, 'Per Hour', 'ewfeww', 'efwwfwfew', 'fwefwefwe'),
(30, 'absaUserName__', 'AI Specialist', 'Health and Fitness Industry', 'Gauteng, Johannesburg', 'Permanent', 8, 20000, 'Per Day', 'knkjnkj', 'jkjnkjkn', 'jknknkjn'),
(31, 'capitecBank', 'Business Analyst', 'Health and Fitness Industry', 'Gauteng, Johannesburg', 'Training', 8, 20000, 'Per Day', 'fytdytdtdtdyd', 'yfufyy', 'vyufuyfuuy'),
(32, 'capitecBank', 'AI Specialist', 'Health and Fitness Industry', 'Gauteng, Johannesburg', 'Training', 8, 20000, 'Per Hour', 'kkkkkkkkkkkkkkkkkkk', 'bbbbbbbbbbbbbbbbbbb', 'nhh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companyprofile`
--
ALTER TABLE `companyprofile`
  ADD PRIMARY KEY (`compID`),
  ADD UNIQUE KEY `comp_Username` (`comp_Username`);

--
-- Indexes for table `jobseeker`
--
ALTER TABLE `jobseeker`
  ADD PRIMARY KEY (`jobSeeker_ID`),
  ADD UNIQUE KEY `jobSeeker_Username` (`jobSeeker_Username`);

--
-- Indexes for table `postedjobs`
--
ALTER TABLE `postedjobs`
  ADD PRIMARY KEY (`JobID`),
  ADD KEY `Test` (`comp_Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companyprofile`
--
ALTER TABLE `companyprofile`
  MODIFY `compID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `jobseeker`
--
ALTER TABLE `jobseeker`
  MODIFY `jobSeeker_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `postedjobs`
--
ALTER TABLE `postedjobs`
  MODIFY `JobID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `postedjobs`
--
ALTER TABLE `postedjobs`
  ADD CONSTRAINT `Test` FOREIGN KEY (`comp_Username`) REFERENCES `companyprofile` (`comp_Username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
