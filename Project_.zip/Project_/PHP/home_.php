<?php
    session_start();
    include("./config/headerHome.php");
    require("./config/server.php");
    $jb_Username = $_SESSION['jb_username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Job Home</title>
    <link rel="stylesheet" href="/Project/CSS/headerHome.css">
    <link rel="stylesheet" href="/Project/CSS/home.css">

</head>
<body>
    <div class="user-type">
        <h2>Search By</h2>
        <ul>
            <li>
                
                <label for="">Company</label>
                <a href="/Project/PHP/jobseeker sign-up.php">Company</a>
            </li>
            <li>
                <a href="/Project/PHP/Freelancer sign-up.php">Location</a>
            </li>
            <li>
                <a href="/Project/PHP/business sign-up.php">Industry</a>
            </li>
        </ul>
    </div>
</body>
</html>

<?php
    include("./config/footer.php");
?>



