<?php
  require("./config/server.php");
  include("./config/header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Project/CSS/payment_.css">
    <title>Document</title>
</head>
<body>
  <br>
    <main>
        <form method="POST" id="user_information_form">
          <h2>Add a Payment Method</h2>
            <div class="row">
              <div class="col-50">
                <h3>Billing Address</h3>
                <!-- Name Field -->
                <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                <input type="text" id="fName" name="firstname" placeholder="Frank Ocean" required title="Please enter your name">
                
                <!-- Email Field -->
                <label for="email"><i class="fa fa-envelope"></i> Email</label>
                <input type="text" id="email" name="email" placeholder="Ocean@example.com" required title="Please enter your email">
                
                <!-- Address Field -->
                <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                <input type="text" id="adr" name="address" placeholder="Kubániho 70, Apt. 225, 18 731, Bratislava II,  Slovakia" required title="Please enter your address">
                
                <!-- City Field -->
                <label for="city"><i class="fa fa-institution"></i> City</label>
                <input type="text" id="city" name="city" placeholder="Johannesburg" required title="Please enter your city name">

                <div class="row">
                  <!-- Zip Field -->
                  <div class="col-50">
                    <label for="zip">Zip</label>
                    <input type="text" id="zip" name="zip" placeholder="1543" required>
                  </div>
                  <!-- Country Field -->
                  <div class="col-50">
                    <label for="country">Country</label>
                    <input type="text" id="country" name="country" placeholder="South Africa" required>
                  </div>
                </div>
              </div>
    
              <div class="col-50">
                <h3>Payment</h3>
                <label for="fname">Accepted Cards</label>
                <div class="icon-container">
                  <img src="https://clipground.com/images/visa-logo-png-6.png" alt="Visa img" height="50px" width="50px">
                  <img src="https://logos-world.net/wp-content/uploads/2020/09/Mastercard-Symbol.jpg" alt="Master-card img" height="50px" width="50px">
                  <img src="https://th.bing.com/th/id/OIP.V0duj2DHUhxVJ4LEb2FodgHaEF?pid=ImgDet&rs=1" alt="American-Express img" height="50px" width="50px">
                  <img src="https://th.bing.com/th/id/OIP._yKy0Fo11nWGwmRIG1ZbvQHaEo?pid=ImgDet&rs=1" alt="Discovery img" height="50px" width="50px">
                </div>
                <label for="cname">Name on Card</label>
                <input type="text" id="cname" name="cardname" placeholder="Frank JK Ocean" required>
                <label for="ccnum">Credit card number</label>
                <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" pattern="[0-9]{16}" title="Please enter a valid 16-digit credit card number">
                <label for="expmonth">Exp Month</label>
                <input type="text" id="expmonth" name="expmonth" placeholder="October" required>
                <div id="monthError-message"></div>
                <div class="row">
                  <div class="col-50">
                    <label for="expyear">Exp Year</label>
                    <input type="text" id="expyear" name="expyear" placeholder="2025" required>
                  </div>
                  <div class="col-50">
                    <label for="cvv">CVV</label>
                    <input type="text" id="cvv" name="cvv" placeholder="932" required>
                  </div>
                </div>
              </div>
              
            </div>
            <label>
              <input type="checkbox" name="sameadr" required> Confirm details
            </label>
            <input type="submit" value="Continue" class="btn">
          </form>
    </main>
    <script src="./JS/validation.js"></script>
    <br><br>
</body>
</html>

<?php
  include("./config/footer.php");
?>