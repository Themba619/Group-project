<?php
    require("./config/server.php");

    if(isset($_GET('DeleteID'))){
        $id = $_GET['DeleteID'];

        $sql = "DELETE FROM postedjobs WHERE JobID = $id";
        $result = mysqli_query($connection, $sql);
        if($result){
            echo "Deleted successfuly";
        }
        else{
            die(mysqli_error($connection));
        }
    }
?>