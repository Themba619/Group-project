<?php
    $connection = new mysqli("localhost", "root", "", "myJobDB");

    $jb_Name = $_POST['fullname'];
    $jb_Surname = $_POST['surname'];
    $jb_Username = $_POST['username'];
    $jb_Email = $_POST['email'];
    $password = $_POST['password'];
    $birthdate = $_POST['birthdate'];

    $sql = "INSERT INTO jobseeker (jobSeeker_Username, jobSeeker_Name, jobSeeker_Surname, jobSeeker_Email, password_, jobSeeker_Birthdate)
    VALUES ('$jb_Username', '$jb_Name','$jb_Surname', '$jb_Email', '$password', '$birthdate')";
    mysqli_query($connection, $sql);

    header("Location: ../home_.php?signup=success");
?>