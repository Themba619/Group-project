<?php
    require("./server.php");

    $bName = $_POST['bName'];
    $comp_Username = $_POST['bUsername'];
    $pPic = $_POST['pPic'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $industry = $_POST['industry'];
    $comp_Descrip = $_POST['comp_Descrip'];
    $contactNum= $_POST['contactNum'];
    $password= $_POST['password'];

    $sql = "INSERT INTO companyprofile (comp_Name, comp_Username, comp_IMG, comp_Address, comp_Email, comp_TelNum, password_, comp_Descrip, Industry)
    VALUES ('$bName', '$comp_Username','$pPic', '$address', '$email', '$contactNum', '$password', '$comp_Descrip', '$industry')";
    mysqli_query($connection, $sql);

    header("Location: ../business login.php?signup=success");
?>