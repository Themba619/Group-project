<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Project/CSS/headerfooterStyle.css">
    <title>Document</title>
</head>
<body>
    <footer>
        <div class="footer-content">
          <p>Email us: example@website.com</p>
          <p></p>
          <div class="social-media">
            <a href="#">Facebook</a>
            <a href="#">Twitter</a>
            <a href="#">Instagram</a>
          </div>
        </div>
    </footer>
</body>
</html>