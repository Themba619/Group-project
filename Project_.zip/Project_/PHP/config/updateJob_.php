<?php
    session_start();
    $connection = new mysqli("localhost", "root", "", "myJobDB");


    // if(count($_POST)>0){
    //     mysqli_query($connection, "UPDATE postedjobs set jobTitle = '" . $_POST['jobTitle'] . "', industry = '" . $_POST['industry'] . "', jobLocation = '" . $_POST['jobLocation'] . "',
    //     cType = '" . $_POST['cType'] . "', workingHours = '" . $_POST['workingHours'] . "', salary = '" . $_POST['salary'] . "', tPeriod = '" . $_POST['tPeriod'] . "',
    //     jDescription = '" . $_POST['jDescription'] . "', sRequired = '" . $_POST['sRequired'] . "', edLevel = '" . $_POST['edLevel'] . "'");
    //     $message = "<p style= 'color: green;'> Record modified successfuly</p>";
    //     // header("Location: ../dash.php?signup=success");
    // }
    // $result = mysqli_query($connection, "SELECT * FROM postedjobs WHERE JobID = '" . $_GET['UpdateID'] ."'");
    // $row = mysqli_fetch_array($result);
    $id = $_GET['UpdateID'];
    if(isset($_POST['submit'])){
        $jName = $_POST['jobTitle'];
        $comp_Username = $_SESSION['comp_Username'];
        $jIndustry = $_POST['industry'];
        $jLocation = $_POST['jobLocation'];
        $cType = $_POST['cType'];
        $Hours= $_POST['workingHours'];
        $Salary= $_POST['salary'];
        $tPeriod = $_POST['tPeriod'];
        $jDescrip = $_POST['jDescription'];
        $sRequired = $_POST['sRequired'];
        $edLevel = $_POST['edLevel'];

        $sql = "UPDATE postedjobs set JobID = '$id', jobName = '$jName', jobSector = '$jIndustry', jobLocation = '$jLocation',
        ContractType = '$cType', workingHours = '$Hours', Salary = '$Salary', S_TimePeriod = '$tPeriod', j_Description = '$jDescrip', skillsRequired = '$sRequired', EdLevels = '$edLevel'
        where JobID = '$id'";
        $result = mysqli_query($connection, $sql);
        if($result){
            echo "Updated successfuly";
        }
    }

    header("Location: ../dash.php?signup=success");
?>