<?php
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/Project/CSS/headerfooterStyle.css">

</head>
<body>
    <header>
		<nav>
			<div class="logo">
				<a href="#"><img src="/Project/Images/download (2).png" alt="Logo"></a>
			</div>
			<div class="menu">
				<ul>
					<li><a href="#">About</a></li>
					<li><a href="#">Free Short Courses</a></li>
				</ul>
			</div>
		</nav>
	</header>
</body>
</html>