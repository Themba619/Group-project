<?php
    include("./config/header.php");
    require("./config/server.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Job</title>
    <link rel="stylesheet" href="/Project/CSS/landing page style.css">
</head>
<body>

    <div class="user-type">
        <h2>Choose your user type:</h2>
        <ul>
            <li><a href="/Project/PHP/jobseeker login.php">Job Seeker</a></li>
            <li><a href="/Project/PHP/Freelancer login.php">Freelancer</a></li>
            <li><a href="/Project/PHP/business login.php">Business</a></li>
        </ul>
    </div>

    <!--<div class="slideshow-container">
        <div class="slide active" style="background-image: url('depositphotos_32552797-stock-photo-cartoon-illustration-negotiations-in-the.jpg')"></div>
        <div class="slide" style="background-image: url('depositphotos_38899171-stock-photo-job-search.jpg')"></div>
        <div class="slide" style="background-image: url('depositphotos_96610920-stock-photo-job-search-requirements-for-employer.jpg')"></div>
    </div>-->
      
    <!--div class="slideshow">
        <div class="slide active" style="background-image: url('depositphotos_32552797-stock-photo-cartoon-illustration-negotiations-in-the.jpg')"></div>
        <div class="slide" style="background-image: url('depositphotos_38899171-stock-photo-job-search.jpg')"></div>
        <div class="slide" style="background-image: url('depositphotos_96610920-stock-photo-job-search-requirements-for-employer.jpg')"></div>
    </div>-->

    <script src="/Project/JS/landing page javascript.js"></script>  
</body>
</html>

<?php
    include("./config/footer.php");
?>