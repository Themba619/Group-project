<?php
    // session_start();
    $id = $_GET['UpdateID'];
    // require("./config/server.php");

    // // if(count($_POST)>0){
    // //     mysqli_query($connection, "UPDATE postedjobs set jobTitle = '" . $_POST['jobTitle'] . "', industry = '" . $_POST['industry'] . "', jobLocation = '" . $_POST['jobLocation'] . "',
    // //     cType = '" . $_POST['cType'] . "', workingHours = '" . $_POST['workingHours'] . "', salary = '" . $_POST['salary'] . "', tPeriod = '" . $_POST['tPeriod'] . "',
    // //     jDescription = '" . $_POST['jDescription'] . "', sRequired = '" . $_POST['sRequired'] . "', edLevel = '" . $_POST['edLevel'] . "'");
    // //     $message = "<p style= 'color: green;'> Record modified successfuly</p>";
    // //     // header("Location: ../dash.php?signup=success");
    // // }
    // // $result = mysqli_query($connection, "SELECT * FROM postedjobs WHERE JobID = '" . $_GET['UpdateID'] ."'");
    // // $row = mysqli_fetch_array($result);
    // $id = $_GET['UpdateID'];
    // if(isset($_POST['Submit'])){
    //     $jName = $_POST['jobTitle'];
    //     $comp_Username = $_SESSION['comp_Username'];
    //     $jIndustry = $_POST['industry'];
    //     $jLocation = $_POST['jobLocation'];
    //     $cType = $_POST['cType'];
    //     $Hours= $_POST['workingHours'];
    //     $Salary= $_POST['salary'];
    //     $tPeriod = $_POST['tPeriod'];
    //     $jDescrip = $_POST['jDescription'];
    //     $sRequired = $_POST['sRequired'];
    //     $edLevel = $_POST['edLevel'];
    //     $sql = "UPDATE postedjobs set JobID = '$id', jobTitle = '$jName', industry = '$jIndustry', jobLocation = '$jLocation',
    //     cType = '$cType', workingHours = '$Hours', salary = '$Salary', tPeriod = '$tPeriod', jDescription = '$jDescrip', sRequired = '$sRequired', edLevel = '$edLevel'
    //     where JobID = '$id'";
    //     $result = mysqli_query($connection, $sql);
    //     if($result){
    //         echo "Updated successfuly";
    //     }
    // }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Post</title>
    <link rel="stylesheet" href="/Project/CSS/postJob_style.css">
    <script src="https://kit.fontawesome.com/1244d8c3ae.js" crossorigin="anonymous"></script>
</head>
<body>

       <form action="config/updateJob_.php?UpdateID='.$id.'" id="form" method="POST" onsubmit="return validateForm()">
        <h1>Update Job</h1>
        <br>
        <div>
            <label  for="jobTitle">Job Title</label>
            <div>
                <input type="text" name="jobTitle" placeholder="e.g. Web Developer" required>
            </div>
        </div>
        <br>
        <Label>Job Sector</Label>
        <div>
            <input type="text" name="industry" placeholder="e.g Tech Industry" required>
        </div>
        <br>
        <div>
            <label  for="jobLocation">Job Location</label>
            <div>
                <input type="text" name="jobLocation" placeholder="Town/ Province" required>
            </div>
        </div>
        <br>
        <Label>Cotract Type</Label>
        <select name="cType" id="format">
            <option selected disabled>Choose Contract Type</option>
            <option value="Permanent">Permanent</option>
            <option value="Contract">Contract</option>
            <option value="Training">Training</option>
            <option value="Temporary">Temporary</option>
            <option value="Voluntary">Voluntary</option>
            <option value="Freelance">Freelance</option>
        </select>
        <br>
        <div>
            <label  for="workingHours">Working Hours</label>
            <div>
                <input type="text" name="workingHours" placeholder="Hours" required>
            </div>
        </div>
        <br>
        <div>
            <label for="salary">Salary</label>
            <div>
                <input type="text" name="salary" placeholder="Amount" required>
            </div>
        </div>
        <br>
        <label for="">Salary Time Period</label>
        <select name="tPeriod" id="format">
            <option selected disabled>Choose Time Period</option>
            <option value="Per Hour">Per Hour</option>
            <option value="Per Day">Per Day</option>
            <option value="Per Hour">Per Month</option>
            <option value="Per Month">Per Month</option>
            <option value="Per Year">Per Year</option>
        </select>
        <br>
        <br>
        <div>
            <label for="jobDescription">Job Description</label>
            <div>
                <textarea name="jDescription" id="" cols="30" rows="10"></textarea >
            </div>
        </div>
        <br>
        <div>
            <label for="Skills">Skills Required</label>
            <div>
                <textarea name="sRequired" id="" cols="30" rows="10"></textarea>
            </div>
        </div>
        <br>
        <br>
        <div>
        <label for="Education">Education Levels Required</label>
        <div>
            <textarea name="edLevel" id="" cols="30" rows="10"></textarea>
        </div>
        </div>
        <br>
        <div>
            <button id="nextBTN" name="submit">Update</button>
        </div>
    </form>
    <br>
    <br>
</body>
</html>