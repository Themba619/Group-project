<?php
    include("./config/header.php");
    require("./config/server.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Seeker Login</title>
    <link rel="stylesheet" href="/Project/CSS/freelancer login.css">
</head>
<body>
    <form action="" method="POST" id="login-form" onsubmit="return validateform()">
        <h2>Freelancer Login</h2>
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button id="next-btn">Login</button>
        <br>
        <div>
            <button type="button" onclick="location.href='Freelancer sign-up.php'" id="login-btn">Dont have an account?</button>
        </div>
    </form>

    <script>
        function validateform() {
        // Check if any input field is empty
        var email = document.getElementsByName("email")[0].value;
        var password = document.getElementsByName("password")[0].value;

        if (email === "" || password === "") {
            alert("All input fields must be filled.");
            return false; // Prevent form submission
        }
        return true; // Allow form submission
    }
    </script>
</body>
</html>

<?php
    include("./config/footer.php");
?>