<?php
    require("./config/server.php");

if(isset($_POST['submit'])){
    // Connect to database
    $connection = new mysqli("localhost","root","","user information");

     // Get values form data.
     $fullName = $_POST['firstname'];
     $email = $_POST['email'];
     $address = $_POST['address'];
     $country = $_POST['country'];
     $city = $_POST['city'];
     $zip = $_POST['zip'];
 
     // Insert data into database
      $sql = "INSERT INTO `customer information`(`Full name`, `Email`, `Address`, `City`, `Country`, `Zip`) 
     VALUES ('$fullName','$email','$address','$country','$city','$zip')";
 
     //Check if values are inserted into the database
    if(mysqli_query($connection, $sql)){
        echo "Data inserted successfully.";
    }else{
        echo "Error: " . mysqli_error($connection);
    }
   
}
?>
