    // function validateForm() {
    //     // Check if any input field is empty
    //     var jName = document.getElementsByName("jobTitle").value;
    //     var jIndustry = document.getElementsByName("industry").value;
    //     var jLocation = document.getElementsByName("jobLocation").value;
    //     var cType = document.getElementsByName("cType").value;
    //     var Hours = document.getElementsByName("workingHours").value;
    //     var Salary = document.getElementsByName("salary").value;
    //     var tPeriod = document.getElementsByName("tPeriod").value;
    //     var jDescrip = document.getElementsByName("jDescription").value;
    //     var srequired = document.getElementsByName("sRequired").value;
    //     var edLevel = document.getElementsByName("edLevel").value;
    //     //var edLevel = document.getElementsByName("edLevel")[0].value;

    //     if (jName == "" || jIndustry == "" || jLocation == "" || cType == "" || Hours == "" || Salary == ""|| tPeriod == "" || jDescrip == "" || srequired == "" || edLevel == "") {
            
    //         alert("All input fields must be filled.");
    //         return false; // Prevent form submission
    //     }
    //     return true; // Allow form submission
    // }
