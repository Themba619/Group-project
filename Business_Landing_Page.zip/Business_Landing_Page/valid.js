// Validate card number
function validateCardNumber() {
  var cardNumberInput = document.getElementById('card_number');
  var cardNumberValue = cardNumberInput.value.replace(/\s/g, ''); // Remove spaces

  if (!cardNumberValue) {
    alert('Please enter a card number.');
    return false;
  }

  if (!/^\d{16}$/.test(cardNumberValue)) {
    alert('Please enter a valid 16-digit card number.');
    return false;
  }

  return true;
}

// Validate expiry date
function validateExpiryDate() {
  var expDateInput = document.getElementById('exp_date');
  var expDateValue = expDateInput.value.trim();

  if (!expDateValue) {
    alert('Please enter an expiry date.');
    return false;
  }

  if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expDateValue)) {
    alert('Please enter a valid expiry date in the format MM/YY.');
    return false;
  }

  return true;
}

// Validate CVV/CVC
function validateCVV() {
  var cvvInput = document.getElementById('cvv');
  var cvvValue = cvvInput.value.trim();

  if (!cvvValue) {
    alert('Please enter a CVV/CVC.');
    return false;
  }

  if (!/^\d{3}$/.test(cvvValue)) {
    alert('Please enter a valid 3-digit CVV/CVC.');
    return false;
  }

  return true;
}

// Validate form on submit
document.getElementById('form').addEventListener('submit', function(event) {
  if (!validateCardNumber() || !validateExpiryDate() || !validateCVV()) {
    event.preventDefault(); // Prevent form submission if validation fails
  }
});