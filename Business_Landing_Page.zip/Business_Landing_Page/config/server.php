<?php
// Connect to database
$connection = new mysqli("localhost","root","","user information");
    
//Check connection
if(!$connection){
    echo"Error not connected";
    die("Connection failed: " . mysqli_connect_error());
}else{
    echo"Connected";
}
?>